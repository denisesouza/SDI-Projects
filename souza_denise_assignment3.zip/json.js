//Denise Souza
//SDI 1410
//Assignment 3 / Project 3
//JSON DATA

var tableInfo = {
    "peopleNames": [{
            "name": "R. Wilson",
            "table": "Souza Family",
            "seat": 1
        }, {
            "name": "E. Lacy",
            "table": "Souza Family",
            "seat": 2
        }, {
            "name": "A. Ellington",
            "table": "Souza Family",
            "seat": 3
        }, {
            "name": "J. Nelson",
            "table": "Souza Family",
            "seat": 4
        }, {
            "name": "P. Garcon",
           "table": "Souza Family",
            "seat": 5
        }, {
            "name": "H. Miller",
            "table": "Souza Family",
            "seat": 6
        }, {
            "name": "K. Wright",
            "table": "Souza Family",
            "seat": 7
        }, {
            "name": "D. Bailey",
            "table": "Souza Family",
            "seat": 8
        }


    ]
};